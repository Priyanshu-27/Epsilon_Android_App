import React, { useState , useRef, useEffect} from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import DocumentPicker from 'react-native-document-picker';
import { get_T_ID,get_S_ID,get_Room_Name, remove_Room_Name } from '../services/Asyncstorage';
import ImagePicker   from 'react-native-image-picker';
import { useNavigation } from '@react-navigation/native';
import { useIsFocused } from '@react-navigation/native';
import Geolocation from '@react-native-community/geolocation';
import MaterialIcon from 'react-native-vector-icons/MaterialIcons'
import showImagePicker from 'react-native-image-picker';
const ChatScreen = ({navigation}) => {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const isFocused = useIsFocused()

  const [room_name, setroom] = useState(null);
  const socketRef = useRef(null);


  // useEffect(() => {
  //   const unsubscribe = navigation.addListener('blur', () => {
  //     // Remove the token from async storage when the user navigates away from this screen
  //   remove_Room_Name('room_name');
  //   });

  //   return unsubscribe;
  // }, [navigation]);
  async function fetchData() {
    const room = await get_Room_Name('room_name');
    setroom(room);
  }
 
  useEffect(() => {
    isFocused && fetchData()
  }, [isFocused]);

  useEffect( () => {
    // Connect to the WebSocket server
    socketRef.current = new WebSocket(`ws://10.0.2.2:8000/ws/chat/${JSON.parse(room_name)}/`);
    
    socketRef.current.onopen = () => {
      console.log('Connected to the WebSocket server');
    };
    socketRef.current.onmessage = () => {
      console.log('Connected to the WebSocket server');
    };
    // socketRef.current.onopen = () => {
    //   console.log('Connected to the WebSocket server');
    // };

    return () => {
      if (socketRef.current) {
        socketRef.current.close();
      }
    };
  }, [room_name]);

  const sendMessage = () => {
    if (message.trim() !== '') {
      setMessages((prevMessages) => [
        ...prevMessages,
        { id: Math.random().toString(), content: message, isMe: true },
      ]);
      setMessage('');
    }
   
  };

 
    const handleDocumentPress = async () => {
      try {
        const result = await DocumentPicker.pick({
          type: [DocumentPicker.types.allFiles],
        });
        setFileUri(result[0].uri);
        setFileName(result[0].name);
        
      } catch (err) {
        if (DocumentPicker.isCancel(err)) {
          console.log('User cancelled file picker');
        } else {
          console.log('DocumentPicker Error: ', err);
        }
      }
     
    };


  const handleCameraPress = () => {
    // ImagePicker.showImagePicker({
    //   mediaType: 'mixed', // Allow images and videos
    //   quality: 1,
    //   allowsEditing: false,
    //   storageOptions: {
    //     skipBackup: true,
    //     path: 'images',
    //   },
    // }, (response) => {
    //   if (response.didCancel) {
    //     console.log('User cancelled image picker');
    //   } else if (response.error) {
    //     console.log('ImagePicker Error: ', response.error);
    //   } else {
    //     // You can upload the selected file to your server or do something else with it
    //     console.log(response.uri, response.type, response.fileName, response.fileSize);
    //     setMessages((prevMessages) => [
    //       ...prevMessages,
    //       { id: Math.random().toString(), content: response.uri, isMe: true },
    //     ]);
    //   }
    // });
  };

  const handleLocationPress = () => {
    // Geolocation.getCurrentPosition(
    //   (position) => {
    //     const location = `https://www.google.com/maps/search/?api=1&query=${position.coords.latitude},${position.coords.longitude}`;
    //     setMessages((prevMessages) => [
    //       ...prevMessages,
    //       { id: Math.random().toString(), content: location, isMe: true },
    //     ]);
    //   },
    //   (error) => {
    //     console.log(error.message);
    //   },
    //   { enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 }
    // );
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#fff' }}>
      {/* Header */}
      <View style={{ height: 60, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#ccc', paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center' }}>
        <TouchableOpacity>
          
        </TouchableOpacity>
        <Text style={{ marginLeft: 10, fontSize: 18 }}>${room_name}</Text>
      </View>

      {/* Chat Messages */}
      <FlatList
        data={messages}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={{ alignItems: item.isMe ? 'flex-end' : 'flex-start', paddingHorizontal: 10, paddingVertical: 5 }}>
            <View style={{ backgroundColor: item.isMe ? '#DCF8C5' : '#fff', padding: 10, borderRadius: 10 }}>
              <Text style={{ color: item.isMe ? '#000' : '#000', fontSize: 16 }}>{item.content}</Text>
            </View>
          </View>
        )}
      />

      {/* Chat Input */}
      <View style={{ height: 60, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#ccc', paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center' }}>
        <TouchableOpacity onPress={handleDocumentPress}>
          <MaterialIcon name="attach-file" size={20} color="#AD40AF" style={styles.IconStyle} />
        </TouchableOpacity>
        <TouchableOpacity onPress={handleCameraPress} >
          <Icon name="camera" size={20} color="#AD40AF" style={styles.IconStyle} />
        </TouchableOpacity>
        <TouchableOpacity onPress={handleLocationPress}>
          <Icon name="map-marker" size={20} color="#AD40AF" style={styles.IconStyle} />
        </TouchableOpacity>
        
        <TextInput
          style={{
            flex: 1, marginRight: 10, height: 40, borderWidth: 1, borderRadius: 20, paddingHorizontal: 10
          }}
          placeholder="Type your message"
          value={message}
          onChangeText={(text) => setMessage(text)}
        />
        <TouchableOpacity onPress={sendMessage}>
          <Icon name="send" size={24} color="#AD40AF" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  IconStyle: {
    marginRight: 5
  }
})
export default ChatScreen;