// import { View, Text } from 'react-native'
// import React from 'react'
// import { useState } from 'react'

// const InitialScreen = ({navigation}) => {
//     // const [Launch , setLaunch]=useState(<initialScreen/>)
// setTimeout(() => {
//     navigation.navigate('Join')
// }, 4000);
//   return (
//     <View style={{fontSize:20 , alignItems:'center' , justifyContent:'center'}}>
// <Text style={{fontSize:20 , alignItems:'center' , justifyContent:'center'}}>Epsilon</Text>
//     </View>
 
//   )
// }

// export default InitialScreen